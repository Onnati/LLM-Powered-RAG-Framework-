import os
from pathlib import Path
from dotenv import load_dotenv

# load dotenv from project root
def load_config():
    env_path = Path(__file__).resolve().parent.parent / '.env'
    return load_dotenv(env_path)

# function to get Google Gemini api key
def get_google_api():
    return os.getenv('GOOGLE_API_KEY')