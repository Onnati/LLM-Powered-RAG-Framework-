# import all necessary libraries
import time
import tempfile
from pathlib import Path
import streamlit as st
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyPDFLoader
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain.chains import create_retrieval_chain
from langchain_objectbox.vectorstores import ObjectBox
from langchain_core.documents import Document
from langchain_core.prompts import ChatPromptTemplate
from objectbox.model.properties import VectorDistanceType
from utils import gemini_llm, huggingface_instruct_embedding, EMBEDDING_DIMENSIONS

PROJECT_ROOT = Path(__file__).resolve().parent.parent
OBJECTBOX_DIR = PROJECT_ROOT / "objectbox"

st.set_page_config(layout='wide', page_title="Objectbox and Langchain")

st.title('Objectbox VectorstoreDB with Gemini 2.5 Flash')

prompt = ChatPromptTemplate.from_template(
    """Use the context below to answer the question. If the answer is not in the context, say you could not find it in the uploaded documents.

Context:
{context}

Question: {input}

Answer:"""
)

# function for vector embedding and Objectbox VectorstoreDB
def close_vector_store():
    vectors = st.session_state.get('vectors')
    if vectors is not None:
        vectors._db.close()
        del st.session_state.vectors


def load_uploaded_documents(uploaded_files):
    documents = []
    for uploaded_file in uploaded_files:
        if uploaded_file.name.lower().endswith(".pdf"):
            with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
                tmp.write(uploaded_file.getvalue())
                tmp_path = tmp.name
            try:
                documents.extend(PyPDFLoader(tmp_path).load())
            finally:
                Path(tmp_path).unlink(missing_ok=True)
        elif uploaded_file.name.lower().endswith(".txt"):
            text = uploaded_file.getvalue().decode("utf-8")
            documents.append(
                Document(page_content=text, metadata={"source": uploaded_file.name})
            )
    return documents


def vector_embedding(uploaded_files):
    close_vector_store()

    if 'embeddings' not in st.session_state:
        st.session_state.embeddings = huggingface_instruct_embedding()

    docs = load_uploaded_documents(uploaded_files)
    if not docs:
        st.error("No content found in the uploaded files.")
        return False

    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    final_documents = text_splitter.split_documents(docs)
    st.session_state.vectors = ObjectBox.from_documents(
        final_documents,
        st.session_state.embeddings,
        embedding_dimensions=EMBEDDING_DIMENSIONS,
        distance_type=VectorDistanceType.COSINE,
        db_directory=str(OBJECTBOX_DIR),
        clear_db=True,
    )
    st.session_state.embedded_file_count = len(uploaded_files)
    st.session_state.embedded_chunk_count = len(final_documents)
    return True


uploaded_files = st.file_uploader(
    "Upload your documents",
    type=["pdf", "txt"],
    accept_multiple_files=True,
)

if st.button('Embedd Documents'):
    if not uploaded_files:
        st.warning("Please upload at least one PDF or TXT file.")
    else:
        with st.spinner('Embedding documents...'):
            if vector_embedding(uploaded_files):
                st.success(
                    f"ObjectBox Database is ready. "
                    f"Embedded {st.session_state.embedded_file_count} file(s) "
                    f"into {st.session_state.embedded_chunk_count} chunks. "
                    f"You can now enter your question."
                )

user_input = st.text_input('Enter your question from documents')


if user_input:
    if 'vectors' not in st.session_state:
        st.warning('Please click "Embedd Documents" first.')
    else:
        document_chain = create_stuff_documents_chain(gemini_llm(), prompt)
        retriever = st.session_state.vectors.as_retriever(search_kwargs={"k": 5})
        retrieval_chain = create_retrieval_chain(retriever, document_chain)
        start = time.process_time()

        response = retrieval_chain.invoke({'input': user_input})

        if not response.get("context"):
            st.warning("No relevant document chunks were retrieved. Try re-embedding your files or asking a more specific question.")

        st.write(response['answer'])
        st.write(f'response time: {(time.process_time() - start):.2f} secs')

        with st.expander("Document Similarity Search"):
            for i, doc in enumerate(response["context"]):
                st.write(doc.page_content)
                st.write("--------------------------------")