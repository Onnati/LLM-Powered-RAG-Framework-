import asyncio

from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_community.embeddings import HuggingFaceBgeEmbeddings
from config import load_config, get_google_api

# load app configuration
load_config()

EMBEDDING_MODEL = "BAAI/bge-small-en-v1.5"
EMBEDDING_DIMENSIONS = 384

_llm_instance = None


def _ensure_event_loop():
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        try:
            loop = asyncio.get_event_loop()
            if loop.is_closed():
                raise RuntimeError
        except RuntimeError:
            asyncio.set_event_loop(asyncio.new_event_loop())


# setup Gemini LLM
def gemini_llm():
    global _llm_instance
    if _llm_instance is None:
        _ensure_event_loop()
        _llm_instance = ChatGoogleGenerativeAI(
            model='gemini-2.5-flash',
            google_api_key=get_google_api(),
        )
    return _llm_instance

# setup huggingface_instruct_embedding
def huggingface_instruct_embedding():
    embeddings = HuggingFaceBgeEmbeddings(
        model_name=EMBEDDING_MODEL,
        model_kwargs={'device': 'cpu'},
        encode_kwargs={'normalize_embeddings': True},
    )

    return embeddings